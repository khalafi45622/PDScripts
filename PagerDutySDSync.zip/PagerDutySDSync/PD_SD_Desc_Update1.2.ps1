﻿#Design By Kevin Khalafi
#Last update: 08/26/2021
#Please run the script from location of .ps1 file

 $scriptPath = (Get-Location).path

if(Test-Path("$scriptPath\config\properties.xml"))
{
    [xml]$XmlDocument = Get-Content -Path "$scriptPath\config\properties.xml"
    $token =  $XmlDocument.PD.PDAPI.token
    $apipath = $XmlDocument.PD.PDAPI.apipath
    $accept = $XmlDocument.PD.PDAPI.accept
    $contentType = $XmlDocument.PD.PDAPI.'content-type'

    $headers=@{}
    $headers.Add("accept", $accept)
    $headers.Add("content-type", $contentType)
    $headers.Add("authorization", "Token token=$token")

    $user = $XmlDocument.PD.SNOW.user
    $password = $XmlDocument.PD.SNOW.password

    $auth = $user + ':' + $password
    $Encoded = [System.Text.Encoding]::UTF8.GetBytes($auth)
    $authorizationInfo = [System.Convert]::ToBase64String($Encoded)
    $headers2 = @{"Authorization"="Basic $authorizationInfo"}

    $flag=1

}else{
       $dt = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
      "$dt -- Warn -- The config file is missig." | Out-File "$scriptPath\log\PDSyncScript.log" -Append
       $flag=0
     }

function Service_Update
{
 [CmdletBinding()]
 param(
        [Parameter(Mandatory=$true)]
        [string]$id,
        [string]$desc
      )
        $d=get-date -format ddMMMyyy


$MyJsonVariable = @"
{
    "service":{
      "type": "service",
      "description": "$desc"
     }
}
"@

 $response = Invoke-RestMethod -Uri "https://api.pagerduty.com/services/$id" -Method PUT -Headers $headers -ContentType 'application/json' -Body $MyJsonVariable
}

if($flag -eq 1)
{

    try{

            $response = Invoke-RestMethod -Uri 'https://api.pagerduty.com/services?total=false&time_zone=UTC&sort_by=name' -Method GET -Headers $headers

            if($response.services)
            {
                  $rp = $response.services | Select-Object id,name,description 
 
                 foreach($lin in $rp)
                 {

                    if(($lin.name).Contains('SN:'))
                    {
                        $name = (($lin.name).split(':'))[1]

                        if($name.Contains('('))
                        {
                          $name =  $name -replace '\s', "%20"
                        }else{
         
                                $x = $name.Split(" ")
                                $x[(($name.Split(" ")).Length)-1] = "("+$x[(($name.Split(" ")).Length)-1] + ")"
                                $name= [string]::join("%20", $x)
         
                         }

                        $p = 'https://safewaystaging1.service-now.com/api/now/table/cmdb_ci_business_app?sysparm_query=name%3D'+$name+'&sysparm_limit=1'
 
                         $x= Invoke-RestMethod -Uri $p -Method GET -Headers $headers2
                         if($x.result)
                             {

                               [string]$description = $x.result.short_description

                               if($description -ne $lin.description)
                               { 
                                 Service_Update -id $lin.id -desc $description 
                                }else{
                                       $SDname = $lin.name
                                       Write-Host "$SDname PagerDuty SD & ServiceNow CI description is in sync."
                                       $dt = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
                                       "$dt -- Info -- $SDname PagerDuty SD description udated." | Out-File "$scriptPath\log\PDSyncScript.log" -Append
                                     }

                             }else{
                                    Write-Host "There is no response from safewaystaging1.service-now.com/api"
                                    $dt = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
                                    "$dt -- Info -- There is no response from safewaystaging1.service-now.com/ap." | Out-File "$scriptPath\log\PDSyncScript.log" -Append
                                  }
                      }
                 }

            }

    }catch{
             Write-Host "Can not reach to api.pagerduty.com or Access denied. Please see logs"
         
             $e = $_.Exception
	         $line = $_.InvocationInfo.ScriptLineNumber
	         $ErrorMessage = $_.Exception.Message
	         $FailedItem = $_.Exception.ItemName
	         $Time=Get-Date
	         $d1=get-date -format MMddyyhhmm
	         "$Time -- there is run time error in line $line. $ErrorMessage -- $FailedItem -- $e"  | add-content "$scriptPath\log\PagerDuty_Script_$d1.err"
    }

} 